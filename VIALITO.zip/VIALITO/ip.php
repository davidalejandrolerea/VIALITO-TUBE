<?php 

$ip = getHostByName(getHostName());

echo "<p style='text-align:center; font-size:100px;'> La direccion del Examen Local</p>";
echo "<p style='font-weight:bold; text-align:center; font-size:100px;'>".$ip."/tics/</p>";
?>