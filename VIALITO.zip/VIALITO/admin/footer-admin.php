
</div><!--CIERRA EL DIV DEL CONTAINER-->
</div>
<div style="height: 120px;">
  
</div>
<footer class="footer container-fluid bg-danger mt-1">


    <div class="row d-flex justify-content-end text-white">

                <div class="col-12 col-md-7 text-md-right">
                    <h1>
                    <!--Facebook-->
                    <a class="fb-ic ml-0">
                        <i class="fab fa-youtube-square mr-0"></i>
                    </a>
                    <!--Twitter-->
                    <a class="tw-ic">
                        <i class="fab fa-twitter-square mr-0"></i>
                    </a>
                    <!--Google +-->
                    <a class="gplus-ic">
                        <i class="fab fa-google-plus-square mr-0"></i>
                    </a>
                    <a href="#"><i class="fas fa-arrow-circle-up"></i></a>
                  </h1>
                </div>
                <!--Grid column-->
      
      </div>
      <div class="row">
        <div class="col-12 text-center pb-3 text-white">
         © 2020 Copyright:
        <a href="https://www.senda3.com/">
            <strong class="text-warning"> VIALITO-TUBE</strong>
        </a>

      </div>
      </div>

</footer>
       



    <script src="js/popper.min.js"></script>

<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.js"></script>

<script>
    	$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

  </body>
</html>
